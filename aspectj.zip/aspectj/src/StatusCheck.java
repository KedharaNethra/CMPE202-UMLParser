class StatusCheck{
	boolean running;
	String name;
	
	
	
	
		
	/**@@param running and name **/
	public StatusCheck(boolean running, String name) {
		this.running = running;
		this.name = name;
	}

	/**@@param name*/
	public StatusCheck(String name) {
		this.name = name;
		this.running = false;
	}
	
	/** @@no param**/
	public StatusCheck() {
		running = false;
	}
	
	/**@param gets the Name and returns the name@@**/
	public String getName() {
		return name;
	}

	/**@param name and set the name@@**/
	
	public void setName(String name) {
		this.name = name;
	}

	
	/**@@ returns running@@*/
	 

	public boolean running() {
		return running;
	}

	/**@param running and the value is set@@**/
	 
	 
	public void setRunning(boolean running) {
		this.running = running;
	}

	}