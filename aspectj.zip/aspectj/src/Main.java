public class Main
{
    public static void main(String [] args)
    {
        TheEconomy s = new TheEconomy();
        Pessimist p = new Pessimist(s);
        Optimist o = new Optimist(s);
        s.attach(p);
        s.attach(o);
        s.setState("The New iPad is out today");
        s.setState("Hey, Its Friday!");
        p.showState();
        o.showState();
        
        
        if (args[0].equals("seq")) {
        	System.out.println("Choose for the diagram type");
        	System.out.println("Requested for" + args[0] + "Diagram");
       //     StartToSeq sp = new StartToSeq(args[0]);
        //    sp.start();
        }
 //       else if (args[0].equals(("sequence"))){
 ///           System.out.println("Entered Sequence");
    //          seq.start();
  //      }
            
        else
        {
            System.out.println("Arguement is invalid " + args[0]);
        }
    }
}